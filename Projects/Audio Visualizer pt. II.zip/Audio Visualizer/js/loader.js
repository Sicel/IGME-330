import {
    init
} from './main.js';

init();
